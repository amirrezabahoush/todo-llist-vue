# todo-app
This is a simple todo app. This app using some mock third-party API as first default list. Then you can see the todo list, add, edit, or remove todos.
By clicking on x icon in completed column of the todo list, status of the todo updates to 'Completed'.
Note: In this sample app you can use first 12 items of third-party data and it has not pagination.
## Project setup
```
You can install project dependencies by runnig: `npm install`
```

### Compiles and hot-reloads for development
```
You can run project in development mode by running: `npm run serve`
```

### Compiles and minifies for production
```
You can build project in development mode by running: npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
